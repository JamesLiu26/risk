import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
      home: Settings(),
      debugShowCheckedModeBanner: false,
    ));

class Settings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("設定",
            style: TextStyle(
              fontSize: 22,
              color: Colors.black,
            )),
        backgroundColor: Color.fromARGB(255, 225, 230, 255),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.blue[800]),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          Spacer(flex: 1),
          Row(children: [
            Text(
              "提醒時間",
              style:
                  TextStyle(fontSize: MediaQuery.of(context).size.width * 0.06),
            ),
          ]),
          line(context),
          Row(children: [
            Text(
              "聯絡我們(醫院相關電話、郵件)",
              style:
                  TextStyle(fontSize: MediaQuery.of(context).size.width * 0.06),
            ),
          ]),
          line(context),
          Row(children: [
            Text(
              "意見回饋",
              style:
                  TextStyle(fontSize: MediaQuery.of(context).size.width * 0.06),
            ),
          ]),
          line(context),
          Spacer(flex: 8)
        ],
      ),
    );
  }
}

Container line(BuildContext context) {
  return Container(
      margin: EdgeInsets.only(top: 5, bottom: 10),
      height: 1,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(color: Colors.grey));
}
