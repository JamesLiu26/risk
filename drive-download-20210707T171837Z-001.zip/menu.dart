import 'package:flutter/material.dart';
import './setting.dart';

Builder menuButton() {
  return Builder(
      builder: (context) => IconButton(
          icon: ImageIcon(AssetImage("images/選單.png"), color: Colors.blue[800]),
          onPressed: () => Scaffold.of(context).openDrawer()));
}

Container menu(context) {
  return Container(
    color: Colors.white,
    height: MediaQuery.of(context).size.height,
    width: MediaQuery.of(context).size.width * 0.7,
    child: Column(
      children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.1),
        Column(
          children: [
            GestureDetector(
                child: Container(
                    width: MediaQuery.of(context).size.width * 0.7,
                    color: Colors.white,
                    child: Row(children: [
                      Image.asset("images/個人資料.png",
                          height: MediaQuery.of(context).size.width * 0.15,
                          width: MediaQuery.of(context).size.width * 0.2),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.05),
                      Text(
                        "個人資料",
                        style: TextStyle(
                            fontSize: MediaQuery.of(context).size.width * 0.05),
                      )
                    ]))),
          ],
        ),
        GestureDetector(
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Settings()));
            },
            child: Container(
                width: MediaQuery.of(context).size.width * 0.7,
                color: Colors.white,
                child: Row(
                  children: [
                    Icon(Icons.settings,
                        size: MediaQuery.of(context).size.width * 0.12,
                        color: Color.fromARGB(255, 0, 160, 233)),
                    SizedBox(width: MediaQuery.of(context).size.width * 0.105),
                    Text(
                      "設定",
                      style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width * 0.05),
                    )
                  ],
                ))),
        GestureDetector(
            child: Container(
                width: MediaQuery.of(context).size.width * 0.7,
                color: Colors.white,
                child: Row(
                  children: [
                    Icon(Icons.logout,
                        size: MediaQuery.of(context).size.width * 0.12,
                        color: Color.fromARGB(255, 0, 160, 233)),
                    SizedBox(width: MediaQuery.of(context).size.width * 0.1),
                    Text(
                      "登出",
                      style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width * 0.05),
                    )
                  ],
                )))
      ],
    ),
  );
}
